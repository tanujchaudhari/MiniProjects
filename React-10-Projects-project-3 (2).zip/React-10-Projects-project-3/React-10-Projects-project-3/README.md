
# Project 3 - DICE GAME

<img width="1154" alt="image" src="https://user-images.githubusercontent.com/50476777/236659200-8ba6c2dc-8815-46ed-bf3e-f873da7a6064.png">


Figma Design URL - https://www.figma.com/file/rephrU2FVgN8MFz6XhnP51/Learn-React-with-10-Projects?type=design&node-id=21-8&t=orp3GQEAXhmtQcgG-0

Visit Website For More Details - https://dosomecoding.com


